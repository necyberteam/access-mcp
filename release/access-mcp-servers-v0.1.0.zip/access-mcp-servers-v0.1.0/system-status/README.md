# system-status

MCP Server for ACCESS-CI system status

## Usage

```bash
node index.js
```
