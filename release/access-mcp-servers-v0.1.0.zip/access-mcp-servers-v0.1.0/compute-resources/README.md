# compute-resources

MCP Server for ACCESS-CI compute resources

## Usage

```bash
node index.js
```
