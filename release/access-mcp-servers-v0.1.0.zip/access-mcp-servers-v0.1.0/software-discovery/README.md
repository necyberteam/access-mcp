# software-discovery

MCP Server for ACCESS-CI software discovery

## Usage

```bash
node index.js
```
